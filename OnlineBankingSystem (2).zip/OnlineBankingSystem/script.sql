create table account_master(
account_id number(10),account_type varchar2(25),account_balance number(15),
open_date date,constraint accid_pk primary key(account_id));

 create table customer (
 account_id number(10),customer_name varchar2(50),email varchar2(30),
 address varchar2(100),pancard varchar2(15),
 constraint cname_pk primary key(customer_name),
 constraint accid_fk foreign key(account_id) references account_master(account_id));
 
 create table transactions(
    transaction_id number,tran_description varchar2(100),
    date_of_transaction date,transaction_type varchar2(1),
    tran_amount number(15),account_no number(10),
    constraint tid_pk primary key(transaction_id),
   constraint accno_fk foreign key(account_no) references account_master(account_id));
   
    create table service_tracker(
    service_id number,
    service_description varchar2(100),
    account_id number(10),
    service_raised_date date,
    service_status varchar2(20),
    constraint sid_pk primary key(service_id),
    constraint accidst_fk foreign key(account_id) references account_master(account_id));
    
    create table user_table(
    account_id number(10),
    user_id number,
    login_password varchar2(15),
    secret_question varchar2(50),
    transaction_password varchar2(15),
    lock_status varchar2(1),
    constraint uid_pk primary key(user_id),
   constraint accidut_fk foreign key(account_id) references account_master(account_id));
   
   
   create table fund_transfer(
    fundtransfer_id number,
    account_id number(10),
    payee_account_id number(10),
    date_of_transfer date,
    transfer_amount number(15),
    constraint fid_pk primary key(fundtransfer_id),
    constraint accidft_fk foreign key(account_id) references account_master(account_id));
    
    
     create table payee_table(
    account_id number,
    payee_account_id number,
    nick_name varchar2(40),
    constraint paccid_pk primary key(payee_account_id),
    constraint accidpt_fk foreign key(account_id) references account_master(account_id));
