package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Account_master;
import com.cg.bean.LoginScreen;
import com.cg.bean.PayeeTable;
import com.cg.bean.Service;
import com.cg.bean.Transactions;
import com.cg.bean.UserTable;
import com.cg.exception.BankException;
import com.cg.user.services.IUserServices;


@Controller
public class BankController {
	
	@Autowired
	IUserServices userSer;
	
	@RequestMapping("/")
	public String first(Model mo)
	{
		System.out.println("Hello world");
		mo.addAttribute("log", new LoginScreen());
		return "OBS_User_Login_View";
	}
	@RequestMapping("/login")
	public String home(Model mo)
	{
		mo.addAttribute("log", new LoginScreen());
		return "OBS_User_Login_View";
	}
	
	@RequestMapping("/forget")
	public String forgetPassword()
	{
		return "OBS_USer_ForgetPassword_View";
	}
	
	@RequestMapping("/forgetController")
	public String forgetCont(@RequestParam("userid") int id,Model mo)
	{
		System.out.println("inside forget controller");
		LoginScreen ls=new LoginScreen();
		ls.setUserID(id);
		UserTable ut=new UserTable();
		try {
			ArrayList aa= userSer.question(ls);
			if(aa.isEmpty()){
				throw new BankException("UserId doesnt exist");
			}
			for (Object object : aa) 
			{
				ut=(UserTable) object;
			}
			
		} catch (BankException e) {
			mo.addAttribute("log", new LoginScreen());
			mo.addAttribute("msg", e.getMessage());
			mo.addAttribute("type", 6);
			return "OBS_User_Login_View";
		}
		mo.addAttribute("userId",ut.getUserId());
		mo.addAttribute("question", ut.getSecret_question());
		mo.addAttribute("answer", ut.getSecret_answer());
		return "OBS_User_Question_View";
	}
	@RequestMapping("/checkAnswer")
	public String checkAnswer(Model mo,@RequestParam("answer") String answer,@RequestParam("userId") int id,@RequestParam("secretAnswer") String sAnswer)
	{	Boolean flag=false;
		LoginScreen ls=new LoginScreen();
		ls.setAnswer(answer);
		ls.setUserID(id);
		try {
			flag=userSer.checkAns(ls,sAnswer );
			System.out.println(flag);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag==true)
			{
			mo.addAttribute("type", 3);
			mo.addAttribute("msg", "Temporary password: #q1w2");
			mo.addAttribute("log", new LoginScreen());
			return "OBS_User_Login_View";
			}
		else{
			mo.addAttribute("type", 5);
			mo.addAttribute("log", new LoginScreen());
			return "OBS_User_Login_View";
		}
	}
	@RequestMapping(value="/checkLogin",method=RequestMethod.POST)
	public String checkLogin(@ModelAttribute("log") @Valid LoginScreen ls,BindingResult result,Model mo)
	{	
		int verify;
		if(result.hasErrors()){
			mo.addAttribute("log", ls);
			return "OBS_User_Login_View";
		}
		System.out.println("inside checkLogin");
		try {
			ArrayList ar=userSer.login(ls);
			if(ar.get(0).toString().equals("SUCCESS"))
			{
				userSer.changeStatus(ls);
				ArrayList<Account_master> al=userSer.getAllDetails(ls);
				mo.addAttribute("list", al);
				mo.addAttribute("userId", ls.getUserID());
				return "OBS_User_HomePage_View";
			}
			if(ar.get(0).toString().equals("LOCK"))
			{	
				verify=1;
				mo.addAttribute("type", verify);
				return "OBS_User_Login_View";
			}
			if(ar.get(0).toString().equals("FAIL"))
			{	
				verify=2;
				mo.addAttribute("type", verify);
				int c=(int) ar.get(1);
				mo.addAttribute("count",c);
				return "OBS_User_Login_View";
			}
			if(ar.get(0).toString().equals("TEMPORARY"))
			{	
				mo.addAttribute("ls", ls);
				return "OBS_User_CheckPassword_View";
			}
		} catch (BankException e) {
			mo.addAttribute("msg", e.getMessage());
			mo.addAttribute("type", 6);
			return "OBS_User_Login_View";
		}
		return null;
	}
	@RequestMapping("homePage1")
	public String homePage1(Model mo,@RequestParam("userId") int userId)
	{
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException e) {
			e.printStackTrace();
		}
		mo.addAttribute("list", al);
		mo.addAttribute("userId", userId);
		return "OBS_User_HomePage_View";
	}
	
	@RequestMapping("/changePass")
	public String changepass(@RequestParam("conformpass") String pass,@RequestParam("userId") int userId,Model mo)
	{
		userSer.changePassword(userId, pass);
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException e) {
			e.printStackTrace();
		}
		mo.addAttribute("list", al);
		mo.addAttribute("userId", userId);
		mo.addAttribute("add", 2);
		return "OBS_User_HomePage_View";
	}
	@RequestMapping(value="/sameAccount",method=RequestMethod.POST)
	public String sameAccount(@RequestParam("id") int id,Model mo){
		LoginScreen ls=new LoginScreen();
		ls.setUserID(id);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException e) {
			e.printStackTrace();
		}
		mo.addAttribute("userId", id);
		mo.addAttribute("list", al);
		return "OBS_User_SaneAccountTransfer_View";
	}
	@RequestMapping("transferSame")
	public String transferSame(@RequestParam("from") int from ,@RequestParam("to") int to,@RequestParam("pay") int pay,@RequestParam("userId") int id,Model mo)
	{
		try {
			userSer.sameTransfer(from, to, pay);
		} catch (BankException e) {
			mo.addAttribute("check", 1);
			mo.addAttribute("msg", e.getMessage());
			LoginScreen ls=new LoginScreen();
			ls.setUserID(id);
			ArrayList<Account_master> al = null;
			try {
				al = userSer.getAllDetails(ls);
			} catch (BankException ex) {
				ex.printStackTrace();
			}
			mo.addAttribute("list", al);
			mo.addAttribute("userId", id);
			return "OBS_User_SaneAccountTransfer_View";
		}

		mo.addAttribute("check", 2);
		mo.addAttribute("msg", "Transfer Successful");
		LoginScreen ls=new LoginScreen();
		ls.setUserID(id);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException ex) {
			ex.printStackTrace();
		}
		mo.addAttribute("list", al);
		mo.addAttribute("userId", id);
		return "OBS_User_SaneAccountTransfer_View";
	}
	@RequestMapping(value="/diffAccount",method=RequestMethod.POST)
	public String diffAccount(Model mo,@RequestParam("id") int userId)
	{
		ArrayList<PayeeTable> pList=(ArrayList<PayeeTable>) userSer.payeeList();
		mo.addAttribute("list",pList);
		mo.addAttribute("payee", new PayeeTable());
		mo.addAttribute("userId",userId);
		return "OBS_User_DifferentAccount_View";
	}
	@RequestMapping("/addPayee")
	public String addPayee(@ModelAttribute("payee") @Valid PayeeTable pt,BindingResult result,Model mo,@RequestParam("userId") int userId){
		if(result.hasErrors()){

			System.out.println("Wrong");
			ArrayList<PayeeTable> pList=(ArrayList<PayeeTable>) userSer.payeeList();
			mo.addAttribute("list",pList);
			mo.addAttribute("payee", pt);
			mo.addAttribute("userId",userId);
			return "OBS_User_DifferentAccount_View";
		}
		try 
		{
			userSer.addPayee(pt);
		} catch (BankException e) {
			ArrayList<PayeeTable> pList=(ArrayList<PayeeTable>) userSer.payeeList();
			mo.addAttribute("list",pList);
			mo.addAttribute("payee", new PayeeTable());
			mo.addAttribute("userId",userId);
			mo.addAttribute("check", 2);
			mo.addAttribute("msg", e.getMessage());
			return "OBS_User_DifferentAccount_View";
		}
		ArrayList<PayeeTable> pList=(ArrayList<PayeeTable>) userSer.payeeList();
		mo.addAttribute("list",pList);
		mo.addAttribute("payee", new PayeeTable());
		mo.addAttribute("userId",userId);
		mo.addAttribute("check", 1);
		mo.addAttribute("msg", "payee added Successfully");
		return "OBS_User_DifferentAccount_View";
	}
	@RequestMapping("/mediator")
	public String mediator(@RequestParam("accountId") int id,Model mo,@RequestParam("userId") int userId){
		System.out.println("in mediator");
		mo.addAttribute("to", id);
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException ex) {
			ex.printStackTrace();
		}
		mo.addAttribute("list", al);
		mo.addAttribute("userId", userId);
		return "OBS_USer_PayeeTransfer_View";
	}
	@RequestMapping("/transfer")
	public String transfer(@RequestParam("from") int from ,@RequestParam("to") int to,@RequestParam("pay") int pay,@RequestParam("userId") int id,Model mo)
	{
		try {
			userSer.sameTransfer(from, to, pay);
		} catch (BankException e) {
			mo.addAttribute("check", 1);
			mo.addAttribute("msg", e.getMessage());
			LoginScreen ls=new LoginScreen();
			ls.setUserID(id);
			ArrayList<Account_master> al = null;
			try {
				al = userSer.getAllDetails(ls);
			} catch (BankException ex) {
				ex.printStackTrace();
			}
			mo.addAttribute("list", al);
			mo.addAttribute("userId", id);
			mo.addAttribute("to", to);
			return "OBS_USer_PayeeTransfer_View";
		}

		mo.addAttribute("check", 2);
		mo.addAttribute("msg", "Transfer Successful");
		LoginScreen ls=new LoginScreen();
		ls.setUserID(id);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException ex) {
			ex.printStackTrace();
		}
		mo.addAttribute("list", al);
		mo.addAttribute("userId", id);
		mo.addAttribute("to", to);
		return "OBS_USer_PayeeTransfer_View";
	}
	@RequestMapping(value="/mini",method=RequestMethod.POST)
	public String mini(@RequestParam("id") int userId,Model mo)
	{	
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException ex) {
			ex.printStackTrace();
		}
		
		mo.addAttribute("list", al);
		mo.addAttribute("userId", userId);
		
		return "OBS_User_MiniStatement_View";
	}
	@RequestMapping("minis")
	public String minis(@RequestParam("userId") int userId,@RequestParam("from") int acc,Model mo)
	{	
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
		} catch (BankException ex) {
			ex.printStackTrace();
		}
		ArrayList<Transactions> trans=null;
		try {
			 trans=userSer.miniStatement(acc);
		} catch (BankException e) {
			e.printStackTrace();
		}
		mo.addAttribute("list", al);
		mo.addAttribute("userId", userId);
		mo.addAttribute("trans",trans);
		return "OBS_User_MiniStatement_View";
	}
	@RequestMapping(value="/detail",method=RequestMethod.POST)
	public String detailed(@RequestParam("id") int userId,Model mo){
		mo.addAttribute("userId", userId);
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<Account_master> al = null;
		try {
			al = userSer.getAllDetails(ls);
			mo.addAttribute("list", al);
		} catch (BankException ex) {
			ex.printStackTrace();
		}
		return "OBS_User_DetailedState_View";
	}
	@RequestMapping("dState")
	public String det(@RequestParam("userId") int userId,@RequestParam("date1") String date1,@RequestParam("date2") String date2,@RequestParam("from") int acc, Model mo) throws BankException{
		ArrayList<Account_master> al = null;
		LoginScreen ls=new LoginScreen();
		try {
		ArrayList<Transactions> detailedList=	(ArrayList<Transactions>) userSer.detailedStatement(date1,date2,acc);
		mo.addAttribute("detailList", detailedList);
		
		ls.setUserID(userId);
		al = userSer.getAllDetails(ls);
		mo.addAttribute("list", al);
		} catch (BankException e) {
			mo.addAttribute("type", 1);
			mo.addAttribute("msg", e.getMessage());
			al = userSer.getAllDetails(ls);
			mo.addAttribute("list", al);
			mo.addAttribute("userId", userId);
			return "OBS_User_DetailedState_View";
		}
		mo.addAttribute("userId", userId);
		return "OBS_User_DetailedState_View";
	}
	@RequestMapping(value="/changeAddress",method=RequestMethod.POST)
	public String changeAddress(@RequestParam("id") int userId,Model mo) {
		mo.addAttribute("userId", userId);
		mo.addAttribute("check", 0);
		System.out.println("bhanus");
		return "OBS_User_ChangeAddress_View";
	}
	@RequestMapping("changeAdd")
	public String changeAdd(@RequestParam("newAddress") String add,@RequestParam("id") int userId,Model mo) {
		userSer.changeAddress(add, userId);
		mo.addAttribute("userId", userId);
		mo.addAttribute("check", 1);
		return "OBS_User_ChangeAddress_View";
	}
	@RequestMapping(value="/chequeBook",method=RequestMethod.POST)
	public String checkBook (@RequestParam("id") int id,Model mo) throws BankException
	{
		mo.addAttribute("userId", id);
		long serviceNo=0;
		try {
			serviceNo=userSer.serviceStatus(id);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mo.addAttribute("serviceNo", serviceNo);
		mo.addAttribute("add",1);
		LoginScreen ls=new LoginScreen();
		ls.setUserID(id);
		ArrayList<Account_master> al=userSer.getAllDetails(ls);
		mo.addAttribute("list", al);
		return "OBS_User_HomePage_View";
	}
	
	@RequestMapping(value="/Status",method=RequestMethod.POST)
	public String status(@RequestParam("id") int id,Model mo) throws BankException
	{
		mo.addAttribute("userId", id);
		return "OBS_User_ChequeStatus_View";
	}
	@RequestMapping("statusId")
	public String statusId(@RequestParam("serviceId") int serviceId,@RequestParam("userId") int userId,Model mo) {
		Service ser=userSer.status(serviceId);
		mo.addAttribute("userId", userId);
		mo.addAttribute("service", ser);
		return "OBS_User_ChequeStatus_View";
	}
	@RequestMapping(value="/changePassword",method=RequestMethod.POST)
	public String changeHomePassword(@RequestParam("id") int userId,Model mo) throws BankException
	{
		mo.addAttribute("userId", userId);
		LoginScreen ls=new LoginScreen();
		ls.setUserID(userId);
		ArrayList<UserTable> user=userSer.getPassword(ls);
		UserTable ut= new UserTable();
		for (UserTable userTable : user) {
			ut= userTable;
		}
		mo.addAttribute("user", ut);
		return "OBS_User_HomePass_View";
	}
}