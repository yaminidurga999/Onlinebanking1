package com.cg.user.dao;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Account_master;
import com.cg.bean.Customer;
import com.cg.bean.LoginScreen;
import com.cg.bean.PayeeTable;
import com.cg.bean.Service;
import com.cg.bean.Transactions;
import com.cg.bean.UserTable;
import com.cg.exception.BankException;


@Repository("userDao")
public class UserDaoImpl implements IUserDao{

	
	@PersistenceContext
	private EntityManager entityManager;
	//------------------------  Online Banking System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	loginDao(LoginScreen l1)
		 - Input Parameters	:	LoginScreen l1
		 - Return Type		:	List<UserTable> 
		 - Throws		    :  	BankException
		 - Author	     	:	Group 5
		 - Creation Date	:	10/11/2017
		 - Description		:	getting all users
		 ********************************************************************************************************/
	@Override
	public List<UserTable> loginDao(LoginScreen l1) throws BankException {
		try {
			String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
			TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
			query.setParameter("uID", l1.getUserID());
			List<UserTable> loginDetails=query.getResultList();
			/*if(loginDetails==null){
				throw new BankException("User Id doest exist");
			}*/
			return  loginDetails;
		}
		catch (Exception e) {
			throw new BankException(e.getMessage()+" Enter correct user id to check your details");
		}
	}
	
	//------------------------  Online Banking System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	changeCount(LoginScreen ls)
			 - Input Parameters	:	LoginScreen ls
			 - Return Type		:	UserTable 
			 - Throws		    :  	BankException
			 - Author	     	:	Group 5
			 - Creation Date	:	10/11/2017
			 - Description		:	increase Lock count of a specific user
			 ********************************************************************************************************/
	@Override
	public UserTable changeCount(LoginScreen ls) throws BankException {
		UserTable ut = null;
		try {
			System.out.println("change count ");
			
			String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
			TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
			query.setParameter("uID", ls.getUserID());
			List<UserTable> loginDetails=query.getResultList();
			for (UserTable userTable : loginDetails) {
				userTable.setLock_count(userTable.getLock_count()+1);
				ut=userTable;
				entityManager.merge(userTable);
				}  
			
		}
		catch(Exception e)
		{
			throw new BankException(e.getMessage()+" Enter correct user id to change lock count");
		}
		
		return ut;
	}
	//------------------------  Online Banking System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	changeStatus(LoginScreen ls)
	 - Input Parameters	:	LoginScreen ls
	 - Return Type		:	void
	 - Throws		    :  	BankException
	 - Author	     	:	Group 5
	 - Creation Date	:	10/11/2017
	 - Description		:	changing Lock status and lock count to lock and 0 of a specific user
	 ********************************************************************************************************/
	@Override
	public void changeStatus(LoginScreen ls) throws BankException {
		String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
		TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
		query.setParameter("uID", ls.getUserID());
		List<UserTable> loginDetails=query.getResultList();
		for (UserTable userTable : loginDetails) {
			userTable.setLock_status("lock");
			userTable.setLock_count(0);
			entityManager.merge(userTable);
		}  	
	}
	//------------------------  Online Banking System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	forgetpassword(LoginScreen ls)
		 - Input Parameters	:	LoginScreen ls
		 - Return Type		:	List<UserTable>
		 - Throws		    :  	BankException
		 - Author	     	:	Group 5
		 - Creation Date	:	10/11/2017
		 - Description		:	changing both lock count and status when user answers correct secret answer
		 ********************************************************************************************************/
	@Override
	public List<UserTable> forgetpassword(LoginScreen ls) throws BankException {
		String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
		TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
		query.setParameter("uID", ls.getUserID());
		List<UserTable> loginDetails=query.getResultList();
		for (UserTable userTable : loginDetails) {
			userTable.setLock_status("active");
			userTable.setLock_count(0);
			entityManager.merge(userTable);
		}  
		return loginDetails;
	}
	//------------------------  Online Banking System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	changePassword(int userId,String pass)
			 - Input Parameters	:	int userId,String pass
			 - Return Type		:	void
			 - Throws		    :  	BankException
			 - Author	     	:	Group 5
			 - Creation Date	:	10/11/2017
			 - Description		:	to change the password
			 ********************************************************************************************************/
	@Override
	public void changePassword(int userId,String pass)
	{
		String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
		TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
		query.setParameter("uID", userId);
		List<UserTable> loginDetails=query.getResultList();
		for (UserTable userTable : loginDetails) {
			userTable.setPassword(pass);
			entityManager.merge(userTable);
		}  
	}
	//------------------------  Online Banking System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getAll(LoginScreen l1)
	 - Input Parameters	:	LoginScreen l1
	 - Return Type		:	ArrayList<Account_master>
	 - Throws		    :  	BankException
	 - Author	     	:	Group 5
	 - Creation Date	:	10/11/2017
	 - Description		:	to get all the accounts of a user
	 ********************************************************************************************************/
	@Override
	public ArrayList<Account_master> getAll(LoginScreen l1) {
			String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
			TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
			query.setParameter("uID", l1.getUserID());
			List<UserTable> loginDetails=query.getResultList();
			ArrayList<Account_master> accounts=new ArrayList<Account_master>();
			for (UserTable userTable : loginDetails) {
				Account_master am=entityManager.find(Account_master.class, userTable.getAccount_id());
				accounts.add(am);
			}
			return  accounts;
		}
	
	//------------------------  Online Banking System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	sameTransfer(int from,int to, int pay)
	 - Input Parameters	:	int from,int to, int pay
	 - Return Type		:	void
	 - Throws		    :  	BankException
	 - Author	     	:	Group 5
	 - Creation Date	:	10/11/2017
	 - Description		:	to transfer the amount from one account to different account
	 ********************************************************************************************************/
	@Override
	public void sameTransfer(int from,int to, int pay) throws BankException{
		Account_master account1=entityManager.find(Account_master.class, from);
		Account_master account2=entityManager.find(Account_master.class, to);
		if(account1.getAccountBlance()<pay)
			throw new BankException("transfer Failed \n Insufficient balance");
		account1.setAccountBlance(account1.getAccountBlance()-pay);
		account2.setAccountBlance(account2.getAccountBlance()+pay);
		entityManager.merge(account1);
		entityManager.merge(account2);
		entityManager.flush();
	}
	
	//------------------------  Online Banking System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	payeeList()
		 - Input Parameters	:	void 
		 - Return Type		:	List<PayeeTable>
		 - Throws		    :  	BankException
		 - Author	     	:	Group 5
		 - Creation Date	:	10/11/2017
		 - Description		:	to get the payee List
		 ********************************************************************************************************/
	@Override
	public List<PayeeTable> payeeList()
	{
		String qStr="FROM PayeeTable";
		TypedQuery<PayeeTable> query=entityManager.createQuery(qStr, PayeeTable.class);
		List<PayeeTable> payeeList=query.getResultList();
		return payeeList;
	}
	
	//------------------------  Online Banking System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addPayee(PayeeTable pt)
			 - Input Parameters	:	PayeeTable pt
			 - Return Type		:	void
			 - Throws		    :  	BankException
			 - Author	     	:	Group 5
			 - Creation Date	:	10/11/2017
			 - Description		:	to add a payee
			 ********************************************************************************************************/
	@Override
	public void addPayee(PayeeTable pt) throws BankException{
		try{
		entityManager.persist(pt);
		entityManager.flush();
		}catch(Exception e){
			throw new BankException("accountID doesnt exist or it may already be in your list");
		}
	}
	
	//------------------------  Online Banking System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	miniStatement(int accountId)
	 - Input Parameters	:	int accountId
	 - Return Type		:	ArrayList<Transactions> 
	 - Throws		    :  	BankException
	 - Author	     	:	Group 5
	 - Creation Date	:	10/11/2017
	 - Description		:	get mini statement
	 ********************************************************************************************************/
	@Override
	public ArrayList<Transactions> miniStatement(int accountId) throws BankException{
		TypedQuery<Transactions> query= entityManager.createQuery("FROM Transactions t WHERE accountId=:ai ORDER BY t.transactionId DESC LIMIT 5",Transactions.class);
		query.setParameter("ai", accountId);
		query.setMaxResults(5);
		List<Transactions> transactionList=	query.getResultList();
		System.out.println(transactionList);
		return (ArrayList<Transactions>) transactionList;
	}
	//------------------------  Online Banking System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	detailedStatement(String dateString1,String dateString2,int acc)
	 - Input Parameters	:	String dateString1,String dateString2,int acc
	 - Return Type		:	ArrayList<Transactions> 
	 - Throws		    :  	BankException
	 - Author	     	:	Group 5
	 - Creation Date	:	10/11/2017
	 - Description		:	get detailed statement between particular dates
	 ********************************************************************************************************/
	@Override
	public List<Transactions> detailedStatement(String dateString1,String dateString2,int acc) throws BankException {
		List<Transactions> tlist=null;
		try{
		        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		        SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yyyy");
		        Date date1 = null;
		        Date date2 = null;
		            try {
						date1 = format1.parse(dateString1);
						date2 = format1.parse(dateString2);
					} catch (Exception e) {
						throw new BankException(" Enter correct date format");
					}
		        String dateTransformed1 = format2.format(date1);
		        String dateTransformed2 = format2.format(date2); 
		        System.out.println("SELECT t FROM Transactions t  WHERE t.dateOfTransaction BETWEEN '"+dateTransformed1+"' AND '"+dateTransformed2+"' AND t.accountId=:ai");
			TypedQuery<Transactions> query= entityManager.createQuery("Select t FROM Transactions t  where t.dateOfTransaction BETWEEN '"+dateTransformed1+"' AND '"+dateTransformed2+"' and t.accountId=:ai",Transactions.class);
			query.setParameter("ai", acc);
			 tlist=	query.getResultList();
					//Query to get transaction details values from database
					for (Transactions transactions : tlist) {
					System.out.println(transactions);
				}
					System.out.println(tlist);
		}catch(Exception e)
		{
			throw new BankException("Entered wrong date");
		}
				return tlist;
	} 
	//------------------------  Online Banking System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	serviceStatus(int userId)
		 - Input Parameters	:	int userId
		 - Return Type		:	long
		 - Throws		    :  	BankException
		 - Author	     	:	Group 5
		 - Creation Date	:	10/11/2017
		 - Description		:	to set a service and get the current service id
		 ********************************************************************************************************/
	@Override
	public long serviceStatus(int userId) throws BankException {
		String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
		TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
		query.setParameter("uID",userId);
		List<UserTable> loginDetails=query.getResultList();	
		UserTable user=new UserTable();
		for (UserTable userTable : loginDetails) {
			user=userTable;
		}
		Service ser=new Service();
		ser.setAccountid(user.getAccount_id());
		ser.setServicedescription("request for cheque book");
				ser.setServiceraiseddate((new java.sql.Date(System.currentTimeMillis())));
		ser.setServicestatus("pending");
		entityManager.persist(ser);
		entityManager.flush();
		
		Query q =  entityManager.createNativeQuery("SELECT service_id.currval FROM DUAL");
		BigDecimal result = (BigDecimal) q.getSingleResult();
		return result.longValue();	
}
	//------------------------  Online Banking System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	changeAddress(String address,int userId)
			 - Input Parameters	:	String address,int userId
			 - Return Type		:	void
			 - Throws		    :  	BankException
			 - Author	     	:	Group 5
			 - Creation Date	:	10/11/2017
			 - Description		:	to change address
			 ********************************************************************************************************/
	
	@Override
	public void changeAddress(String address,int userId)
	{
		String qStr="SELECT user FROM UserTable user WHERE user.userId= :uID";
		TypedQuery<UserTable> query=entityManager.createQuery(qStr, UserTable.class);
		query.setParameter("uID",userId);
		List<UserTable> loginDetails=query.getResultList();	
		for (UserTable userTable : loginDetails) {
			Customer cus=entityManager.find(Customer.class, userTable.getAccount_id());
			cus.setAddress(address);
			entityManager.merge(cus);
		}
	}
	//------------------------  Online Banking System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	status(int serviceNo)
	 - Input Parameters	:	int serviceNo
	 - Return Type		:	Service
	 - Throws		    :  	NA
	 - Author	     	:	Group 5
	 - Creation Date	:	10/11/2017
	 - Description		:	to get the status of the service
	 ********************************************************************************************************/

	@Override
	public Service status(int serviceNo)
	{
		Service ser=entityManager.find(Service.class, serviceNo);
		return ser;
	}
	//------------------------  Online Banking System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	setTrasaction(int from ,int to,int pay)
		 - Input Parameters	:	int from ,int to,int pay
		 - Return Type		:	void
		 - Throws		    :  	NA
		 - Author	     	:	Group 5
		 - Creation Date	:	10/11/2017
		 - Description		:	to record the transaction in Transactions Table
		 ********************************************************************************************************/
	@Override
	public void setTrasaction(int from ,int to,int pay){
		Transactions trans=new Transactions();
		trans.setAccountId(from);
		trans.setDateOfTransaction((new java.sql.Date(System.currentTimeMillis())));
		trans.setTransactionAmount(pay);
		trans.setTransactionDicription("Debited");
		trans.setTrnsactionType("d");
		entityManager.persist(trans);
		entityManager.flush();
		Transactions trans1=new Transactions();
		trans1.setAccountId(to);
		trans1.setDateOfTransaction((new java.sql.Date(System.currentTimeMillis())));
		trans1.setTransactionAmount(pay);
		trans1.setTransactionDicription("Credited");
		trans1.setTrnsactionType("c");
		entityManager.persist(trans1);
		entityManager.flush();
	}
	
}