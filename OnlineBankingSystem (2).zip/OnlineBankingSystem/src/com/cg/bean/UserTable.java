package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_table")
public class UserTable {
	@Id
	@Column(name="account_id")
	private int accountId;
	
	@Column(name="user_id")
	private int userId;
	
	@Column(name="login_password")
	private  String password;
	
	@Column(name="secret_question")
	private String secretQuestion;
	
	@Column(name="secret_answer")
	private String secretAnswer;
	
	@Column(name="transaction_password")
	private int trasactionPassword;
	
	@Column(name="lock_status")
	private String lockStatus;
	
	@Column(name="lock_count")
	private int lockCount;
	
	
	public int getLock_count() {
		return lockCount;
	}
	public void setLock_count(int lock_count) {
		this.lockCount = lock_count;
	}
	public int getAccount_id() {
		return accountId;
	}
	public void setAccount_id(int account_id) {
		this.accountId = account_id;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecret_question() {
		return secretQuestion;
	}
	public void setSecret_question(String secret_question) {
		this.secretQuestion = secret_question;
	}
	public String getSecret_answer() {
		return secretAnswer;
	}
	public void setSecret_answer(String secret_answer) {
		this.secretAnswer = secret_answer;
	}
	public int getTrasactionPassword() {
		return trasactionPassword;
	}
	public void setTrasactionPassword(int trasaction_password) {
		this.trasactionPassword = trasaction_password;
	}
	public String getLock_status() {
		return lockStatus;
	}
	public void setLock_status(String lock_status) {
		this.lockStatus = lock_status;
	}
	@Override
	public String toString() {
		return "UserTable [accountId=" + accountId + ", userId=" + userId
				+ ", password=" + password + ", secretQuestion="
				+ secretQuestion + ", secretAnswer=" + secretAnswer
				+ ", trasactionPassword=" + trasactionPassword
				+ ", lockStatus=" + lockStatus + ", lockCount=" + lockCount
				+ "]";
	}
	
}
