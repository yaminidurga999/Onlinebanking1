
package com.cg.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="transactions")
public class Transactions {
	@Id 
	@SequenceGenerator(name="seq",sequenceName="transaction_seq",initialValue=2113,allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@Column(name="TRANSACTION_ID")
	private int transactionId;
	@Column(name="TRAN_DESCRIPTION")
	private String transactionDicription;
	@Column(name="DATEOFTRANSACTION")
	private Date dateOfTransaction;
	@Column(name="TRANSACTIONTYPE")
	private String trnsactionType;
	@Column(name="TRANSAMOUNT")
	private int	transactionAmount;
	@Column(name="ACCOUNT_ID")
	private int accountId;
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactionDicription=" + transactionDicription
				+ ", dateOfTransaction=" + dateOfTransaction + ", trnsactionType=" + trnsactionType
				+ ", transactionAmount=" + transactionAmount + ", accountId=" + accountId + "]";
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDicription() {
		return transactionDicription;
	}
	public void setTransactionDicription(String transactionDicription) {
		this.transactionDicription = transactionDicription;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTrnsactionType() {
		return trnsactionType;
	}
	public void setTrnsactionType(String trnsactionType) {
		this.trnsactionType = trnsactionType;
	}
	public int getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
}