package com.cg.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="account_master")
public class Account_master {
	@Id
	@Column(name="account_id")
	private int accoutId;
	@Column(name="account_type")
	private String accountType;
	@Column(name="account_balance")
	private int accountBlance;
	@Column(name="open_date")
	private Date openDate;
	
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public int getAccoutId() {
		return accoutId;
	}
	public void setAccoutId(int accoutId) {
		this.accoutId = accoutId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getAccountBlance() {
		return accountBlance;
	}
	public void setAccountBlance(int accountBlance) {
		this.accountBlance = accountBlance;
	}
}
